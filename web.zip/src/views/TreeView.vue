<!--  -->
<script setup>
// import * as $3Dmol from '3dmol/build/3Dmol.js';;
import Display3D from "../components/Display3D.vue";
</script>
<template>
<div class=''>
    <Display3D></Display3D>
</div>
</template>


<style scoped>
.mol-container {
  width:    75%;
  height:   400px;
  position: relative;
}
</style>